import pandas as pd
import sys
import matplotlib.pyplot as plt
x=[]
y=[]
Death_growing_rate=[]
deaths=pd.read_csv(r'C:\Users\lenovo\Desktop\time_series_covid_19_deaths modified.csv',delimiter=',')
country_deaths=[list(row) for row in deaths.values]
for i in range(0,245):
    t1=0
    for j in range(1,76):
        t1=t1+country_deaths[i][j]
    x.append(t1)
            
recovered=pd.read_csv(r'C:\Users\lenovo\Desktop\time_series_covid_19_recovered modified.csv',delimiter=',')
country_recovered=[list(row) for row in recovered.values]
for i in range(0,245):
    t2=0
    for j in range(3,76):
        t2=t2+country_recovered[i][j]
    y.append(t2)


deaths=pd.read_csv(r'C:\Users\lenovo\Desktop\high_risk_countries_deaths.csv',delimiter=',')
high_risk_countries_deaths=[list(row) for row in deaths.values]       


deaths=pd.read_csv(r'C:\Users\lenovo\Desktop\high_risk_countries_recovered.csv',delimiter=',')
high_risk_countries_recovered=[list(row) for row in deaths.values]


print("1.Death_growing_rates of all countries \n2.death_growing_rate of countries more than 4% \n3.Death growing rate countries with 100% \n4.high_risk_countries_for which indian students go for study,internship etc., \n5.specific data regarding death growing %")
print('\nenter which condition you want to be executed: ')
n=int(input())

for i in range(0,245):
    if x[i]+y[i]==0:
        t=0
        round(t,2)
        Death_growing_rate.append(t)
    else:
        a=0
        a=(x[i]/(x[i]+y[i]))*100
        b=round(a,2)                  
        Death_growing_rate.append(b)



if n==1:
    for i in range(0,245):
        print(i+1,country_deaths[i][0],"\t",Death_growing_rate[i])  
       
elif n==2:
    for i in range(0,245):
        if Death_growing_rate[i]>=4 and Death_growing_rate[i]!=100: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])

elif n==3:
    print('There are countries with 100%death growing rate in which there are 0 recovered patients')
    for i in range(0,245):
        if Death_growing_rate[i]==100:
            print(country_recovered[i][0],' ',Death_growing_rate[i])
    
elif n==4:
    print('press a number to know its corresponding graphical plot deaths vs recovered')
    print('press 0 to exit')
    for i in range(0,15):
        print(i+1,high_risk_countries_deaths[i][0])
    for i in range(0,15):
        g=int(input())
        if(g==1 or g==2 or g==3 or g==4 or g==5 or g==6 or g==7 or g==8 or g==9 or g==10 or g==11 or g==12 or g==13 or g==14 or g==15):
            popped_element1=high_risk_countries_deaths[g-1].pop(0)
            popped_element2=high_risk_countries_recovered[g-1].pop(0)
            plt.plot(high_risk_countries_deaths[g-1],high_risk_countries_recovered[g-1])
            plt.xlabel("high_risk_countries_deaths")
            plt.ylabel("high_risk_countries_recovered)")
            plt.show() 
        elif g==0:
            sys.exit(g)
elif n==5:
    print("Death Growing rate \n1.Between 4% and 10% \n2.between 10% and 30% \n3.between 30% and 50% \n4.between  50% and 70% \n5.between 70% and 90% \n6.between 90% and 100%")

w=int(input("which detail you want to know:"))
print("\n")
if w==1:
    for i in range(0,245):
        if Death_growing_rate[i]>=4 and Death_growing_rate[i]<=10: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])
elif w==2:
     for i in range(0,245):
        if Death_growing_rate[i]>10 and Death_growing_rate[i]<=30: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])
elif w==3:
     for i in range(0,245):
        if Death_growing_rate[i]>30 and Death_growing_rate[i]<=50: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])
elif w==4:
     for i in range(0,245):
        if Death_growing_rate[i]>50 and Death_growing_rate[i]<=70: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])
elif w==5:
     for i in range(0,245):
        if Death_growing_rate[i]>70 and Death_growing_rate[i]<=90: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])
elif w==6:
     for i in range(0,245):
        if Death_growing_rate[i]>90 and Death_growing_rate[i]<=100: 
            print(country_recovered[i][0],' ',Death_growing_rate[i])

print("\n")
























