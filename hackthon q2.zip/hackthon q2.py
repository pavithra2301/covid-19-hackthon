import time
import pandas as pd
df = pd.read_excel("COVID DATA IN US STATES.xlsx", sheet_name=0)
a = list(df['STATE'])
b = list(df['TOTAL NUMBER OF PEOPLE EFFECTED'])
c = list(df['NUMBER OF DEATHS IN AGE (15-25)']) 
print("List of countries affected by covid-19:\nCountry:           Number of people:")
for i in range(10):
  print("%12s            %d"%(a[i],b[i]))
print("\n\n")
time.sleep(2)
for i in range(10):
  for j in range(9):
    if b[j]<b[j+1]:
      x=b[j]
      b[j]=b[j+1]
      b[j+1]=x
      y=a[j]
      a[j]=a[j+1]
      a[j+1]=y
      z=c[j]
      c[j]=c[j+1]
      c[j+1]=z
    
print("Top 5 countries in which greater than 30,000 people are affected  :\nCountry:            Number of people:")
for i in range(5):
  print("%12s            %d"%(a[i],b[i]))
print("\n\n")
time.sleep(2)
for i in range(10):
  for j in range(9):
    if c[j]<c[j+1]:
      x=b[j]
      b[j]=b[j+1]
      b[j+1]=x
      y=a[j]
      a[j]=a[j+1]
      a[j+1]=y
      z=c[j]
      c[j]=c[j+1]
      c[j+1]=z
print("Top 5 countries affected by covid-19 in between the age (15-25):\nCountry:             Number of cases:")
for i in range(5):
  print("%12s            %d"%(a[i],c[i]))
print("\n\n")
time.sleep(1)
print("Pictograph of number of cases:(# = 7 cases)")
for i in range(5):
    t=int(c[i]/7)
    print("%12s:"%a[i],end="")
    for j in range(t):
       print("#",end="")
       print("")



